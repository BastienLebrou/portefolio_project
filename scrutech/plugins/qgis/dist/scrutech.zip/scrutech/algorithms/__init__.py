"""ScruTech Processing algorithms."""
